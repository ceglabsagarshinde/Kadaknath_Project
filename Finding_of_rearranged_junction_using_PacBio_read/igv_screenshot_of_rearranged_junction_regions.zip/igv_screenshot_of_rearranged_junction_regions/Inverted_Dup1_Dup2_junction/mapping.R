#index PacBio_sequence 
bwa index SRR6189090.54824.fa.gz

#bwa mapping of 101 individuals resequencing data
for i in $(ls *_1.fastq.gz); 
do j=`echo $i|sed 's/_1/_2/g'`; 
k=`echo $i|sed 's/_1.fastq.gz/.sam/g'`;
bwa mem -t32 SRR6189090.54824.fa.gz $i $j > $k;
samtools view -@ 32 -bhS $k > $k.bam;
samtools sort -@ 32 $k.bam -o $k.sorted.bam;
rm $k $k.bam
done

#index bam file 
for i in *sorted.bam;do samtools index $i ;done
#subset bam file
for i in *sorted.bam;do samtools view -b $i SRR6189090.54824 >$i.junction2.bam; done

