#index PacBio sequence using BWA
bwa index SRR6189090.111279.fa.gz

#bwa mapping of 101 individuals resequencing data 
for i in $(ls *_1.fq.gz); 
do j=`echo $i|sed 's/_1/_2/g'`; 
k=`echo $i|sed 's/_1.fq.gz/.sam/g'`;
bwa mem -t8 SRR6189090.111279.fa.gz $i $j > $k;
samtools view -bhS $k > $k.bam;
samtools sort $k.bam -o $k.sorted.bam;
rm $k $k.bam
done

#index bam file
for i in *sorted.bam;do samtools index $i ;done

#subset bam file 
for i in *sorted.bam;do samtools view -b $i @SRR6189090.111279 >$i.junction.bam; done

