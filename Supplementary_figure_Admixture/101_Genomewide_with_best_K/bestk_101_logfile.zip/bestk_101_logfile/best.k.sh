#calculate best K for Admixture collect all log file informatin in single file 
(for log in `ls *.log`; do grep -Po 'like=\K[^ ]+' $log; done) > 101_logfile
#writec table in R
R
logs <- as.data.frame(read.table("101_logfile"))
logs$K <- c(rep("1", 15), rep("2", 15), rep("3", 15), rep("4",15), rep("5", 15), rep("6", 15), rep("7", 15), rep("8", 15),rep("9", 15),rep("10", 15),rep("11", 15),rep("12", 15),rep("13", 15),rep("14", 15),rep("15", 15))
write.table(logs[, c(2, 1)], "101_logfile_formatted", row.names = F, col.names = F, quote = F)

#101_logfile_formatted load these file on  clumpack online server and get the best K base on probability
